//引入所有过滤器
import toTime from './toTime'
import toPrice from './toPrice'

//导出
export default {
    toTime,
    toPrice
}