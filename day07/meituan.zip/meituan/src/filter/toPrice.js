export default function toPrice(price,num){
    return price.toFixed(num)
}