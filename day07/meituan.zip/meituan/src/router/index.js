import Vue from 'vue'
import Router from 'vue-router'
//引入一级路由
import Index from '@/components/views/index'
import moiveList from '@/components/views/movieList'
import movieDetail from '@/components/views/movieDetail'
import foodList from '@/components/views/foodList'
import foodDetail from '@/components/views/foodDetail'
//引入二级路由
import Home from '@/components/pages/home'
import Sort from '@/components/pages/sort'
import Cart from '@/components/pages/cart'
import Mine from '@/components/pages/mine'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path:'/index',
      component:Index,
      children:[
        {
          path:'/home',
          component:Home
        },
        {
          path:'/cart',
          component:Cart
        },
        {
          path:'/sort',
          component:Sort
        },
        {
          path:'/mine',
          component:Mine
        },
        {
          path:'',
          redirect:'/home'
        }
      ]
    },
    {
      path:'/movieList',
      component:moiveList
    },
    {
      path:'/movieDetail/:id',
      component:movieDetail
    },
    {
      path:'/foodList',
      component:foodList
    },
    {
      path:'/foodDetail/:id',
      //name 是路由命名
      name:'foodDetail',
      component:foodDetail
    },
    {
      path:'*',
      redirect:'/index'
    }
  ]
})
