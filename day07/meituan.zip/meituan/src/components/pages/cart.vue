<template>
    <div>
        <h1>购物车</h1>
    </div>
</template>

<script>
export default {
    data() {
        return {

        };
    },
};
</script>

<style  lang="" scoped>

</style>
