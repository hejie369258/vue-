<template>
    <div>
        <h1>movieDetail</h1>
        <h1>接收到query参数是---{{$route.query.id}}</h1>
        <hr>
        <h1>接收到params的参数是----{{$route.params.id}}</h1>
    </div>
</template>

<script>
export default {
    data() {
        return {

        };
    },
    mounted() {
        console.log(this,'组件实例')
        console.log(this.$route.query.id)
    },
};
</script>

<style  lang="" scoped>

</style>
