//引入组件
import goBack from './goBack.vue'
import goSearch from './goSearch.vue'

//导出
export default {
    goBack,
    goSearch
}