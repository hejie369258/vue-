<template>
    <div>
        <button class="iconfont icon-sousuo" @click='goSearch'>搜索</button>
    </div>
</template>

<script>
export default {
    data() {
        return {

        };
    },
    methods: {
        goSearch(){
            console.log('搜索中')
        }
    },
};
</script>

<style  lang="" scoped>

</style>
