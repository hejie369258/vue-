<template>
    <div>
        <button class="iconfont icon-fanhui" @click='$router.back()'>返回</button>
    </div>
</template>

<script>
export default {
    data() {
        return {

        };
    },
};
</script>

<style  lang="" scoped>

</style>
